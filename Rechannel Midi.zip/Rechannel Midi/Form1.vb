﻿Imports System.IO
Imports Melanchall.DryWetMidi.Common
Imports Melanchall.DryWetMidi.Core
Imports Melanchall.DryWetMidi.Interaction
Imports Melanchall.DryWetMidi.Tools

Public Class Form1
    Public Property n As Integer

    Public Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form2.Hide()
        Form2.Label1.Text = "Total Files Replaced channel  :    "
        If Labelroot.Text = "" Then
            MessageBox.Show("Select a Folder to replace channel !!!")
            Exit Sub
        End If

        Dim rutadirectorio As String = Labelroot.Text
        Dim archivosendirectorio() As String = System.IO.Directory.GetFiles(rutadirectorio, "*.*")

        For Each archivo As String In archivosendirectorio
            If archivo.EndsWith(".mid") Then
                Dim midiFile = Melanchall.DryWetMidi.Core.MidiFile.Read(archivo)
                midiFile.ProcessNotes(Sub(n) n.Channel = (TextBox1.Text))
                midiFile.Write(archivo, True, MidiFileFormat.SingleTrack)

            Else
                MessageBox.Show("Folder without midi files or mixed with another files extensions")
                Exit Sub
            End If
        Next

        Dim rutadirectorio2 As String = Labelroot.Text
        Dim archivosendirectorio2() As String = System.IO.Directory.GetFiles(rutadirectorio2)
        Dim filesnopath As String = ""
        For Each archivo As String In archivosendirectorio2
            filesnopath += Path.GetFileName(archivo) & vbCrLf
        Next

        Form2.TextBox1.Clear()
        Form2.Show()
        Form2.TextBox1.Text = filesnopath

        Form2.TextBox1.Text = Form2.TextBox1.Text.Substring(0, Form2.TextBox1.Text.LastIndexOf(Environment.NewLine))
        Dim howmany As Integer = Form2.TextBox1.Lines.Length
        Form2.Label1.Text = Form2.Label1.Text & howmany.ToString
        Form2.TextBox1.SelectionLength = 0

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim files As New FolderBrowserDialog
        If files.ShowDialog = DialogResult.OK Then
            Labelroot.Text = files.SelectedPath
        Else
            Labelroot.Text = ""
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Labelroot.Text = ""
    End Sub
End Class
